﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ToyRobotStimulator
{
    class Movement
    {
        public Movement(Robot robot)
        {
            this.robot = robot;
        }

        Robot robot { get; set; }

        /// <summary>
        /// Validates the command entered by user and performs the action
        /// </summary>
        /// <param name="input">Commands</param>
        /// <returns>Command status (Output message)</returns>
        public string Command(string input)
        {
            string output = "Invalid Command."; //Error message to display if entered input is not valid.
            string placeError = "Robot is not yet placed on the table.";
            int xCordinate;
            int yCordinate;
            Actions action;
            Directions direction;

            //Validates the input command and returns the arguments if valid. 
            if (ValidateInput(input, out xCordinate, out yCordinate, out action, out direction))
            {
                switch (action)
                {
                    case Actions.PLACE:
                        if (robot.PlaceRobot(xCordinate, yCordinate, direction)) //Place robot on the table based on X,Y cordinates and direction.
                        {
                            output = "Robot Placed Successfully.";
                        }
                        else
                        {
                            output = "Invalid position. Provided position is outside the dimension of table."; //Print error if position is invalid.
                        }
                        break;
                    case Actions.MOVE:
                        if (robot.ValidateRobotPlaced()) //Validate if robot is placed on table before moving.
                        {
                            if (robot.Move())//Moves Robot by one unit.
                            {
                                output = "Robot Moved Successfully.";
                            }
                            else
                            {
                                output = "Robot cannot be moved to this position.";
                            }
                        }
                        else
                        {
                            output = placeError;
                        }
                        break;
                    case Actions.LEFT:
                        if (robot.ValidateRobotPlaced())//Validate if robot is placed on table before rotating.
                        {
                            if (robot.RotateLeft())//Rotates robot to left.
                            {
                                output = "Robot Rotated to Left.";
                            }
                        }
                        else
                        {
                            output = placeError;
                        }
                        break;
                    case Actions.RIGHT:
                        if (robot.ValidateRobotPlaced())//Validate if robot is placed on table before rotating.
                        {
                            if (robot.RotateRight())//Rotate robot to right.
                            {
                                output = "Robot Rotated to Right.";
                            }
                        }
                        else
                        {
                            output = placeError;
                        }
                        break;
                    case Actions.REPORT:
                        if (robot.ValidateRobotPlaced())//Validate if robot is placed on table before printing position.
                        {
                            output = robot.ReportPosition();//Returns the current position of the robot.
                        }
                        else
                        {
                            output = placeError;
                        }
                        break;
                    default:
                        break;
                }
            }
            return output;
        }

        /// <summary>
        /// Validates the input entered by the user.
        /// </summary>
        /// <param name="input">Input command</param>
        /// <param name="x">returns x cordinate from input command</param>
        /// <param name="y">returns y cordinate from input command</param>
        /// <param name="action">returns action from input command</param>
        /// <param name="direction">returns direction from input command</param>
        /// <returns>returns x,y cordinates and direction</returns>
        public bool ValidateInput(string input, out int x, out int y, out Actions action, out Directions direction)
        {
            bool IsValid = false;
            action = Actions.INVALID; //setting default value to invalid
            direction = Directions.INVALID; //setting default value to invalid
            x = 0;
            y = 0;

            if (input.ToUpper().StartsWith("PLACE")) //Checks if the entered command starts with PLACE to extract X,Y cordinates and direction from command.
            {
                string[] placeArray = input.Split(' ');
                string command = placeArray[0].ToUpper();
                if (Enum.TryParse(command, out action))//Checks if the entered command is in Actions Enum List.
                {
                    if (action == Actions.PLACE && placeArray.Length == 2) //Checks if command is valid and has 2 parts (second part id x,y cordicates and direction e.g. 1,2,NORTH)
                    {
                        string[] positionArray = placeArray[1].Split(','); //Position 1 will have the comma separated arguments for Place command. Eg: 0,0,NORTH
                        //Verifies all 3 arguments are passed and first 2 arguments are valid integers and 3rd argument is present in the Directions Enum List.
                        if (positionArray.Length == 3 && int.TryParse(positionArray[0], out x) && int.TryParse(positionArray[1], out y) && Enum.TryParse(positionArray[2].ToUpper(), out direction))
                        {
                            IsValid = true;
                        }
                    }
                }
            }
            else if (Enum.TryParse(input.ToUpper(), out action))//If command is not starting with Place, verify the command is a valid action (MOVE, LEFT, RIGHT, REPORT)
            {
                IsValid = true;
            }

            return IsValid;
        }
    }

    /// <summary>
    /// Actions Enumerator
    /// </summary>
    public enum Actions
    {
        INVALID = 0,
        PLACE = 1,
        MOVE = 2,
        RIGHT = 3,
        LEFT = 4,
        REPORT = 5
    }

    /// <summary>
    /// Directions Enumerator
    /// </summary>
    public enum Directions
    {
        INVALID = 0,
        EAST = 1,
        WEST = 2,
        NORTH = 3,
        SOUTH = 4
    }
}
