﻿using System;
using System.Linq;

namespace ToyRobotStimulator
{
    class Program
    {
        static void Main(string[] args)
        {

            Movement mv = new Movement(new Robot()); //Creates object of robot and movement class.
            //Title
            Console.WriteLine("---------------------");
            Console.WriteLine("Toy Robot Stimulator!");
            Console.WriteLine("---------------------");
            Console.WriteLine();
            while (true)
            {
                string input = Console.ReadLine();
                //Prints output
                Console.WriteLine(mv.Command(input));
                Console.WriteLine();
            }
        }
    }

    //Can be created in separate class file
    class Robot
    {
        //Global variables
        public int _xCordinate; //By default will be 0
        public int _yCordinate;
        public int _tableSize = 5; //Table size 5x5
        public bool _IsRobotPlaced = false;
        public Directions _direction;

        /// <summary>
        /// Moves the robot forward by one unit in the direction it is currently facing.
        /// </summary>
        /// <returns>Returns true if move is successful or else false.</returns>
        public bool Move()
        {
            bool isValid = false;
            switch (this._direction)
            {
                case Directions.EAST:
                    if (this._xCordinate + 1 <= 5)
                    {
                        isValid = true;
                        this._xCordinate = this._xCordinate + 1;
                    }
                    break;
                case Directions.WEST:
                    if (this._xCordinate - 1 >= 0)
                    {
                        isValid = true;
                        this._xCordinate = this._xCordinate - 1;
                    }
                    break;
                case Directions.NORTH:
                    if (this._yCordinate + 1 <= 5)
                    {
                        isValid = true;
                        this._yCordinate = this._yCordinate + 1;
                    }
                    break;
                case Directions.SOUTH:
                    if (this._yCordinate - 1 >= 0)
                    {
                        isValid = true;
                        this._yCordinate = this._yCordinate - 1;
                    }
                    break;
                default:
                    break;
            }

            return isValid;
        }

        /// <summary>
        /// Rotates the direction of the Robot to Left
        /// </summary>
        /// <returns>Returns true if rotate is successful or else false.</returns>
        public bool RotateLeft()
        {
            bool isRotatedLeft = false;
            switch (this._direction)
            {
                case Directions.EAST:
                    this._direction = Directions.NORTH;
                    isRotatedLeft = true;
                    break;
                case Directions.WEST:
                    this._direction = Directions.SOUTH;
                    isRotatedLeft = true;
                    break;
                case Directions.NORTH:
                    this._direction = Directions.WEST;
                    isRotatedLeft = true;
                    break;
                case Directions.SOUTH:
                    this._direction = Directions.EAST;
                    isRotatedLeft = true;
                    break;
                default:
                    break;
            }
            return isRotatedLeft;
        }

        /// <summary>
        /// Rotates the direction of the Robot to Right
        /// </summary>
        /// <returns>Returns true if rotate is successful or else false.</returns>
        public bool RotateRight()
        {
            bool isRotatedRight = false;
            switch (this._direction)
            {
                case Directions.EAST:
                    this._direction = Directions.SOUTH;
                    isRotatedRight = true;
                    break;
                case Directions.WEST:
                    this._direction = Directions.NORTH;
                    isRotatedRight = true;
                    break;
                case Directions.NORTH:
                    this._direction = Directions.EAST;
                    isRotatedRight = true;
                    break;
                case Directions.SOUTH:
                    this._direction = Directions.WEST;
                    isRotatedRight = true;
                    break;
                default:
                    break;
            }
            return isRotatedRight;
        }

        /// <summary>
        /// Places the robot on the table
        /// </summary>
        /// <param name="x">X Cordinate</param>
        /// <param name="y">Y Cordinate</param>
        /// <param name="d">Direction</param>
        /// <returns>Return true if the robot is placed on table or else false.</returns>
        public bool PlaceRobot(int x, int y, Directions d)
        {
            bool IsValidPosition = false;
            if (x >= 0 && x <= 5 && y >= 0 && y <= 5) //Places the robot on the table only if the position is between the range 5x5 (0-5).
            {
                _xCordinate = x;
                _yCordinate = y;
                _direction = d;
                IsValidPosition = _IsRobotPlaced =  true;
            }
            return IsValidPosition;
        }

        /// <summary>
        /// Prints the current position of the robot on the table
        /// </summary>
        /// <returns>Position</returns>
        public string ReportPosition()
        {
            //Sets X cordinate Y cordinate and Direction of the Robot
            string position = string.Format("OUTPUT: {0},{1},{2}", this._xCordinate, this._yCordinate, this._direction);
            return position;
        }

        /// <summary>
        /// Validates Robot is placed on the table or not.
        /// </summary>
        /// <returns>Returns the status</returns>
        public bool ValidateRobotPlaced()
        {
            return this._IsRobotPlaced;
        }
    }
}
